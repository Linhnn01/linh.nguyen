# max1000-template
Quartus project template with generic pin assignments and clock constraints for Arrow's MAX1000 board

Board URL: <https://www.arrow.com/en/products/max1000/arrow-development-tools>
